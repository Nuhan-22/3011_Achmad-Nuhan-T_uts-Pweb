<a href="?action=create">Tambah</a> | <a href="?action=export">Export CSV</a>
<table border="1" cellpadding="6" cellspacing="0">
<tr><th>ID</th><th>Nama</th><th>Email</th><th>Phone</th><th>Aksi</th></tr>
<?php foreach ($contacts as $c): ?>
<tr>
<td><?= htmlspecialchars($c['id']) ?></td>
<td><?= htmlspecialchars($c['name']) ?></td>
<td><?= htmlspecialchars($c['email']) ?></td>
<td><?= htmlspecialchars($c['phone']) ?></td>
<td>
<a href="?action=edit&id=<?= $c['id'] ?>">Edit</a> |
<a href="?action=delete&id=<?= $c['id'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
</td>
</tr>
<?php endforeach; ?>
</table>