<form method="post" action="?action=store">
<label>Nama<br><input type="text" name="name"></label><br>
<label>Email<br><input type="email" name="email"></label><br>
<label>Phone<br><input type="text" name="phone"></label><br>
<button type="submit">Simpan</button>
</form>