<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>MVC App</title>
<link rel="stylesheet" href="/mvc_app/public/assets/style.css">
</head>
<body>
<div class="container">
<h1>MVC — Aplikasi Contoh</h1>
<?php if (isset($content)) echo $content; ?>
</div>
</body>
</html>