<form method="post" action="?action=update">
<input type="hidden" name="id" value="<?= htmlspecialchars($contact['id']) ?>">
<label>Nama<br><input type="text" name="name" value="<?= htmlspecialchars($contact['name']) ?>"></label><br>
<label>Email<br><input type="email" name="email" value="<?= htmlspecialchars($contact['email']) ?>"></label><br>
<label>Phone<br><input type="text" name="phone" value="<?= htmlspecialchars($contact['phone']) ?>"></label><br>
<button type="submit">Update</button>
</form>