<?php
}


public function index() {
$contacts = $this->model->all();
$this->render('contacts/index', ['contacts' => $contacts]);
}


public function create() {
$this->render('contacts/create');
}


public function store() {
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$this->model->create(['name' => $name, 'email' => $email, 'phone' => $phone]);
header('Location: /mvc_app/public/');
}


public function edit() {
$id = $_GET['id'] ?? null;
$contact = $this->model->find($id);
$this->render('contacts/edit', ['contact' => $contact]);
}


public function update() {
$id = $_POST['id'] ?? null;
$this->model->update($id, [
'name' => $_POST['name'] ?? '',
'email' => $_POST['email'] ?? '',
'phone' => $_POST['phone'] ?? ''
]);
header('Location: /mvc_app/public/');
}


public function delete() {
$id = $_GET['id'] ?? null;
$this->model->delete($id);
header('Location: /mvc_app/public/');
}


public function exportCsv() {
$items = $this->model->all();
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="contacts.csv"');
$out = fopen('php://output', 'w');
fputcsv($out, ['id','name','email','phone']);
foreach ($items as $it) {
fputcsv($out, [$it['id'],$it['name'],$it['email'],$it['phone']]);
}
fclose($out);
exit;
}
}