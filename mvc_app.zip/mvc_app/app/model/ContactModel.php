<?php


class ContactModel {
private $storagePath;


public function __construct() {
$this->storagePath = __DIR__ . '/../../storage/data.json';
if (!file_exists($this->storagePath)) {
file_put_contents($this->storagePath, json_encode([]));
}
}


private function readAll() {
$json = file_get_contents($this->storagePath);
return json_decode($json, true) ?: [];
}


private function writeAll($data) {
file_put_contents($this->storagePath, json_encode($data, JSON_PRETTY_PRINT));
}


public function all() {
return $this->readAll();
}


public function find($id) {
$items = $this->readAll();
foreach ($items as $item) {
if ($item['id'] == $id) return $item;
}
return null;
}


public function create($data) {
$items = $this->readAll();
$id = time() . rand(100,999);
$data['id'] = $id;
$items[] = $data;
$this->writeAll($items);
return $id;
}


public function update($id, $data) {
$items = $this->readAll();
foreach ($items as &$item) {
if ($item['id'] == $id) {
$item = array_merge($item, $data);
$this->writeAll($items);
return true;
}
}
return false;
}


public function delete($id) {
$items = $this->readAll();
$new = [];
}