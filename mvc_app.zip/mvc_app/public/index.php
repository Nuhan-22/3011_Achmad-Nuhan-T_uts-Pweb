<?php
// Simple front controller
require_once __DIR__ . '/../app/Controllers/ContactController.php';


$controller = new ContactController();
$action = isset($_GET['action']) ? $_GET['action'] : 'index';


switch ($action) {
case 'create':
$controller->create();
break;
case 'store':
$controller->store();
break;
case 'edit':
$controller->edit();
break;
case 'update':
$controller->update();
break;
case 'delete':
$controller->delete();
break;
case 'export':
$controller->exportCsv();
break;
default:
$controller->index();
}